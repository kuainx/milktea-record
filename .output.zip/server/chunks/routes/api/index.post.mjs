import { c as defineEventHandler, r as readBody, e as createError, p as prisma } from '../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { name, logo } = body;
  if (!name) {
    throw createError({
      statusCode: 400,
      statusMessage: "Brand name is required"
    });
  }
  const brand = await prisma.brand.create({
    data: {
      name,
      logo
    }
  });
  return brand;
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
