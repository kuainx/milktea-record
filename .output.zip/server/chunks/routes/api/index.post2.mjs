import { c as defineEventHandler, r as readBody, e as createError, p as prisma } from '../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { date, brandId, productName, sugar, price, channel } = body;
  if (!date || !brandId || !productName || !price) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing required fields"
    });
  }
  const order = await prisma.order.create({
    data: {
      date: new Date(date),
      brandId: parseInt(brandId),
      productName,
      sugar: sugar || "Standard",
      price: parseFloat(price),
      channel: channel || "Store"
    }
  });
  return order;
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
