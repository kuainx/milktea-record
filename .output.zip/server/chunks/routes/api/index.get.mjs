import { c as defineEventHandler, p as prisma } from '../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler(async (event) => {
  const brands = await prisma.brand.findMany({
    orderBy: {
      createdAt: "desc"
    }
  });
  return brands;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
