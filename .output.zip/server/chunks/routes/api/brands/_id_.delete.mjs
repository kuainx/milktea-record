import { c as defineEventHandler, g as getRouterParam, e as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__delete = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const ordersCount = await prisma.order.count({
    where: {
      brandId: parseInt(id)
    }
  });
  if (ordersCount > 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "Cannot delete brand with existing orders"
    });
  }
  const brand = await prisma.brand.delete({
    where: {
      id: parseInt(id)
    }
  });
  return brand;
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
