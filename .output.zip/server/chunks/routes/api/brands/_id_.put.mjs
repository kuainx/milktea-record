import { c as defineEventHandler, g as getRouterParam, r as readBody, e as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { name, logo } = body;
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const brand = await prisma.brand.update({
    where: {
      id: parseInt(id)
    },
    data: {
      name,
      logo
    }
  });
  return brand;
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
