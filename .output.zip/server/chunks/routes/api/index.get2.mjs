import { c as defineEventHandler, f as getQuery, p as prisma } from '../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const { date, startDate, endDate, brandId, productName } = query;
  const where = {};
  if (date) {
    const searchDate = new Date(String(date));
    const startOfDay = new Date(searchDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(searchDate);
    endOfDay.setHours(23, 59, 59, 999);
    where.date = {
      gte: startOfDay,
      lte: endOfDay
    };
  } else {
    if (startDate) {
      where.date = { ...where.date, gte: new Date(String(startDate)) };
    }
    if (endDate) {
      const end = new Date(String(endDate));
      end.setHours(23, 59, 59, 999);
      where.date = { ...where.date, lte: end };
    }
  }
  if (brandId) {
    where.brandId = parseInt(String(brandId));
  }
  if (productName) {
    where.productName = {
      contains: String(productName)
    };
  }
  const orders = await prisma.order.findMany({
    where,
    include: {
      brand: true
    },
    orderBy: {
      date: "desc"
    }
  });
  return orders;
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
