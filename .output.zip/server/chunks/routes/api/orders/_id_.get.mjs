import { c as defineEventHandler, g as getRouterParam, e as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "ID is required"
    });
  }
  const order = await prisma.order.findUnique({
    where: {
      id: parseInt(id)
    },
    include: {
      brand: true
    }
  });
  return order;
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
