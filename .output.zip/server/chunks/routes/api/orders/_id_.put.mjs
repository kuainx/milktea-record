import { c as defineEventHandler, g as getRouterParam, r as readBody, e as createError, p as prisma } from '../../../_/nitro.mjs';
import 'node:crypto';
import '@prisma/client-runtime-utils';
import 'node:path';
import 'node:fs';
import 'node:async_hooks';
import 'node:events';
import 'node:os';
import 'node:buffer';
import '@prisma/adapter-mariadb';
import 'node:http';
import 'node:https';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { date, brandId, productName, sugar, price, channel } = body;
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing order ID"
    });
  }
  const order = await prisma.order.update({
    where: {
      id: parseInt(id)
    },
    data: {
      date: date ? new Date(date) : void 0,
      brandId: brandId ? parseInt(brandId) : void 0,
      productName,
      sugar,
      price: price ? parseFloat(price) : void 0,
      channel
    }
  });
  return order;
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
